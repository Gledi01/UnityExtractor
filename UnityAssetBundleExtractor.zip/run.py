import ua1
ua1.start_app()
