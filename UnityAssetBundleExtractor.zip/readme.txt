Indonesian:

ini adalah unity assets bundle extractor,, yang di gunakan untuk mengekstrak atau membuka asset dari game unity seperti .unity3d .bundle

cara menjalankan

Linux:

pip install UnityPy Pillow pygame

python run.py

usahakan device yang kamu gunakan adalah pc/laptop atau jika ingin menggunakan di ponsel anda harus memakai vnc agar GUI NYA kelihatan, karena kode ini berbasis gui


english:



This is a unity assets bundle extractor,, which is used to extract or open assets from unity games such as .Unity3d .bundle

how to run

Linux:

pip install unitypy pillow pygame
Python Run.Py

Try the device that you use is a PC/laptop or if you want to use it on your phone you have to use VNC so that the GUI is visible, because this code is based on GUI

